import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BlogService, BlogModel } from '../../services/blog.service';

@Component({
  selector: 'app-blog-detail',
  templateUrl: './blog-detail.component.html',
  styleUrls: ['./blog-detail.component.css']
})
export class BlogDetailComponent implements OnInit {
  blog?: BlogModel;

  constructor(
    private blogService: BlogService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    const id = +this.route.snapshot.params['id'];
    this.blogService.getBlog(id).subscribe(data => {
      this.blog = data;
    });
  }

  editBlog(): void {
    if (this.blog) {
      this.router.navigate(['/blog-form', this.blog.blogId]);
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
