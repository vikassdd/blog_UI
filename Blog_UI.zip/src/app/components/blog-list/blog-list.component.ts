import { Component, OnInit } from '@angular/core';
import { BlogService, BlogModel } from '../../services/blog.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.css']
})
export class BlogListComponent implements OnInit {
  blogs: BlogModel[] = [];

  constructor(private blogService: BlogService, private router: Router) { }

  ngOnInit(): void {
    this.blogService.getBlogs().subscribe(data => {
      this.blogs = data;
    });
  }

  createBlog(): void {
    this.router.navigate(['/blog-form']);
  }

  editBlog(blog: BlogModel): void {
    this.router.navigate(['/blog-form', blog.blogId]);
  }

  deleteBlog(id: number): void {
    this.blogService.deleteBlog(id).subscribe(() => {
      this.blogs = this.blogs.filter(blog => blog.blogId !== id);
    });
  }
}
