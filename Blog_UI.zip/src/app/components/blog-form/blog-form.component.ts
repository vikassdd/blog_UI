import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BlogService, BlogModel } from '../../services/blog.service';

@Component({
  selector: 'app-blog-form',
  templateUrl: './blog-form.component.html',
  styleUrls: ['./blog-form.component.css']
})
export class BlogFormComponent implements OnInit {
  blogForm: FormGroup;
  isEditMode = false;
  blogId?: number;

  constructor(
    private fb: FormBuilder,
    private blogService: BlogService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.blogForm = this.fb.group({
      text: [''],
      userName: ['']
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.blogId = +params['id'];
        this.blogService.getBlog(this.blogId).subscribe(data => {
          this.blogForm.patchValue(data);
        });
      }
    });
  }

  onSubmit(): void {
    if (this.isEditMode) {
      const updatedBlog: BlogModel = {
        ...this.blogForm.value,
        blogId: this.blogId!,
        dateCreated: new Date() // This should be the original dateCreated in a real app
      };
      this.blogService.updateBlog(updatedBlog).subscribe(() => {
        this.router.navigate(['/']);
      });
    } else {
      const newBlog: BlogModel = {
        ...this.blogForm.value,
        blogId: 0, // This will be set by the server
        dateCreated: new Date()
      };
      this.blogService.createBlog(newBlog).subscribe(() => {
        this.router.navigate(['/']);
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/']);
  }
}
